# 24. What is the purpose of the small, s, and mark tags?

These are less common but useful semantic text-level tags:

```html
<small>: Represents side comments or "small print," such as copyright notices or legal disclaimers. It renders the text in a smaller font size but semantically indicates that the content is of a lower importance or is supplementary.1
```

```html
<s> (Strikethrough): Represents content that is no longer accurate or relevant. It is semantically different from <del> (deleted text), which is used to indicate text that has been removed from a document. The <s> tag is for things that are still visible but marked as incorrect, like an old price on an e-commerce site.
```

```html
<mark>: Represents a run of text in one document which is marked or highlighted for reference purposes, due to its relevance in another context. A common use case is to highlight search terms within a results page.1 By default, browsers render this with a yellow background.
```

```html
<footer>    <p><small>© 2025 Company Inc.</small></p></footer><p>Price: <s>$99.99</s> $79.99</p><p>Your search for "semantic" returned the following result: The use of <mark>semantic</mark> HTML is a best practice.</p>
```
