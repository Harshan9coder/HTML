# 61. How do you create a form in HTML?

```html
An HTML form is created using the <form> element, which acts as a container for various input controls.4 These controls allow users to enter data, which can then be submitted to a server for processing.
```

```html
The <form> element has two essential attributes:
```

action: Specifies the URL of the server-side script that will process the form data (e.g., /submit-form.php).8

method: Specifies the HTTP method to be used when submitting the form data. The two most common methods are GET and POST.8

```html
Inside the <form> tags, you place form controls like <input>, <textarea>, <select>, and <button>.
```

```html
<form action="/register" method="post">    <label for="username">Username:</label>    <input type="text" id="username" name="username">    <button type="submit">Submit</button></form>
```
