# 7. How do you link a JavaScript file to an HTML document?

```html
JavaScript is included in an HTML document using the <script> tag.1 The most common and recommended method is to link to an external JavaScript file using the
```

src attribute.

```html
The conventional best practice is to place <script> tags just before the closing </body> tag.14 This placement is a direct consequence of the browser's rendering pipeline and is a fundamental performance optimization. When the HTML parser encounters a
```

```html
<script> tag (without async or defer attributes), it must halt parsing, fetch the script from the network, execute it, and only then resume parsing the rest of the document. If a script is placed in the <head>, it blocks the rendering of all visible content below it. This can result in a blank page for the user until the script is fully processed, leading to a poor perceived performance. By placing scripts at the end of the <body>, the browser can parse and render the entire visible page first, ensuring the user sees content as quickly as possible. The script can then load and execute afterward, adding interactivity to the already-visible elements.
```

```html
<!DOCTYPE html><html><head>    <title>Linking JavaScript</title></head><body>    <p id="demo">This text will be changed by JavaScript.</p>    <script src="app.js"></script></body></html>
```
