# 97. What is progressive rendering?

Progressive rendering is a broad term for techniques used to render content for display as quickly as possible to improve perceived load time, rather than waiting for the entire page to load before rendering anything.14 The goal is to get meaningful content in front of the user as fast as possible.

HTML-related strategies that contribute to progressive rendering include:

```html
Placing CSS in the <head>: This allows the browser to start building the render tree early.
```

```html
Placing JavaScript at the end of the <body> (or using defer): This prevents scripts from blocking the initial rendering of the page content.
```

Optimizing the Critical Rendering Path: Ensuring that the HTML, CSS, and JavaScript needed to render the "above-the-fold" content (the part of the page visible without scrolling) are loaded and processed first.
