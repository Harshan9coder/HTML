# 20. When should you use <figure> and <figcaption>?

```html
The <figure> element is used to enclose a unit of content, such as an image, illustration, diagram, code snippet, or quote, that is referenced from the main content but can be moved to another part of the page (or to an appendix) without affecting the main flow.1
```

```html
The <figcaption> element provides a caption or legend for the content within the <figure>. It is semantically linked to the <figure> element, which provides a powerful accessibility benefit: screen readers will announce the caption as being directly associated with the figure's content. This is a significant improvement over placing a <p> tag next to an <img>, where the association is only visual.
```

```html
<figure>    <img src="chart.png" alt="A bar chart showing quarterly profits.">    <figcaption>Fig. 1 - Quarterly Profits for Fiscal Year 2025.</figcaption></figure><figure>    <pre><code>function hello() {    console.log("Hello, world!");}</code></pre>    <figcaption>A simple JavaScript function to log a greeting.</figcaption></figure>
```
