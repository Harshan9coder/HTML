# 99. What are some best practices for writing clean HTML?

Writing clean, professional HTML is about more than just getting the syntax right. It involves adhering to a set of conventions and principles that make the code maintainable, accessible, and performant.7

Use Semantic HTML: Choose elements that accurately describe their content.

Maintain a Logical Structure: Use a proper heading hierarchy and ensure the source order makes sense.

Validate Your Code: Regularly check your HTML for errors.

Separate Content from Presentation: Use HTML for structure and CSS for styling. Avoid inline styles.

Write Readable Code: Use consistent indentation and formatting to make the code easy to read.

Prioritize Accessibility: Always include alt text for images, use labels for forms, and ensure keyboard navigability.

Comment Your Code: Add comments to explain complex or non-obvious parts of the markup.

Optimize for Performance: Follow best practices for image optimization and script loading.
