# 50. How do you create responsive images?

Responsive images are a crucial performance optimization technique for modern websites that are viewed on a wide range of devices with different screen sizes and resolutions. The goal is to serve the most appropriately sized image file for the user's context, avoiding the download of unnecessarily large images on small screens. There are two primary HTML techniques for this 2:

Resolution Switching with srcset: The srcset attribute allows you to provide a list of different-sized versions of the same image. The browser can then choose the most suitable one based on the user's screen resolution and viewport size. The sizes attribute can be used alongside srcset to give the browser more context about how large the image will be displayed at different viewport widths.

```html
Art Direction with <picture>: The <picture> element is used when you need to serve entirely different images for different contexts, not just different sizes of the same image. This is known as "art direction." For example, you might show a wide, landscape-oriented image on a desktop and a cropped, portrait-oriented version of the same subject on a mobile device. The <picture> element contains multiple <source> elements, each with a media query, and a final <img> element as a fallback.
```

```html
<img src="cat-small.jpg"     srcset="cat-medium.jpg 1000w, cat-large.jpg 2000w"     sizes="(max-width: 600px) 480px, 800px"     alt="A cute cat."><picture>    <source media="(min-width: 800px)" srcset="landscape.jpg">    <source media="(min-width: 400px)" srcset="portrait.jpg">    <img src="square.jpg" alt="A beautiful landscape."></picture>
```
