# 56. Can you make an image a clickable link?

```html
Yes. To make an image a clickable link, you simply need to wrap the <img> element within an <a> (anchor) tag.19 The
```

```html
href attribute of the <a> tag will define the link's destination.
```

```html
<a href="https://example.com">    <img src="logo.png" alt="Visit our homepage"></a>
```
