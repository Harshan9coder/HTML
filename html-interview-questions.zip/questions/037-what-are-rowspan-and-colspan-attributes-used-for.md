# 37. What are rowspan and colspan attributes used for?

```html
The rowspan and colspan attributes are used on <th> or <td> elements to make a single cell span across multiple rows or columns, respectively.2
```

colspan="number": Merges a cell with one or more cells to its right in the same row. The value "number" indicates how many columns the cell should span.

rowspan="number": Merges a cell with one or more cells below it in subsequent rows. The value "number" indicates how many rows the cell should span.

These are useful for creating complex table layouts where headers or data points apply to multiple categories.

```html
<table border="1">    <caption>Employee Schedule</caption>    <thead>        <tr>            <th>Name</th>            <th colspan="2">Availability</th>        </tr>        <tr>            <th></th> <th>Morning</th>            <th>Afternoon</th>        </tr>    </thead>    <tbody>        <tr>            <td>Alice</td>            <td rowspan="2">Available</td>            <td>Not Available</td>        </tr>        <tr>            <td>Bob</td>            <td>Available</td>        </tr>    </tbody></table>
```
