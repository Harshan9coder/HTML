# 76. What is Web Storage, and what is the difference between localStorage and sessionStorage?

Web Storage is an HTML5 API that provides a way for web pages to store key/value data locally within the user's browser, offering a more modern and powerful alternative to cookies.8 There are two types of Web Storage:

sessionStorage:

Stores data for only one session.

The data is cleared as soon as the user closes the browser tab or window.

The data is specific to that tab; data stored in one tab is not accessible in another tab, even if it's from the same origin.

Useful for storing temporary data related to a single user journey, like information in a multi-step form.

localStorage:

Stores data with no expiration date.

The data persists even after the browser tab and window are closed and will be available the next time the user visits the site.

Data is shared across all tabs and windows from the same origin.

Useful for storing user preferences, application state, or data that should be remembered between visits.

The following table provides a detailed comparison of client-side storage mechanisms.13

Feature

cookie

sessionStorage

localStorage

Initiator

Client or Server

Client

Client

Expiry

Manually set

On tab close

Never expires

Persistence

Yes (if expiry is set)

No

Yes

Sent with HTTP Requests

Yes, automatically

No

No

Capacity

~4 KB

~5-10 MB

~5-10 MB

Accessibility

Any window (same origin)

Same tab only

Any window (same origin)
