# 19. What is the difference between <article> and <section>?

This is a common point of confusion, but the distinction is crucial for correct semantic structuring.6

The key difference is self-containment.

```html
An <article> should make sense on its own, as a complete unit of content. If you were to syndicate it in an RSS feed, it should be fully understandable without the context of the rest of the page. A blog post is the canonical example. An <article> can contain <section>s.
```

```html
A <section> is a way to group related content together within a larger document. It is not necessarily self-contained. Its content is thematically related, but it might not make sense if removed from the context of the page. Think of chapters in a book or different tabbed panels on a settings page. A <section> can contain <article>s (e.g., a "Latest News" section containing multiple article summaries).
```

```html
A simple test is to ask: "Would this content make sense if it were the only thing on the page or in an RSS feed?" If the answer is yes, it's likely an <article>. If not, it's likely a <section>.
```
