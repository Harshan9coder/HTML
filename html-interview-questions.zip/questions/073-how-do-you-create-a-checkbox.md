# 73. How do you create a checkbox?

```html
A checkbox is created using <input type="checkbox">. Unlike radio buttons, multiple checkboxes in a group can be selected simultaneously. If you want to group them logically for server-side processing, you can give them the same name attribute, often with square brackets (``) to indicate an array of values to the server-side language.
```

```html
<fieldset>    <legend>Select your toppings:</legend>    <input type="checkbox" id="topping1" name="toppings" value="pepperoni">    <label for="topping1">Pepperoni</label><br>    <input type="checkbox" id="topping2" name="toppings" value="mushrooms">    <label for="topping2">Mushrooms</label><br>    <input type="checkbox" id="topping3" name="toppings" value="onions">    <label for="topping3">Onions</label></fieldset>
```
