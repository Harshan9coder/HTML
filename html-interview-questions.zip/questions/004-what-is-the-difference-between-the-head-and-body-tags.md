# 4. What is the difference between the <head> and <body> tags?

```html
The <head> and <body> elements are the two main children of the <html> root element, and they serve entirely different purposes.1
```

```html
The <head> Element: This section contains metadata—information about the HTML document that is not displayed directly on the page.1 It is processed by the browser before the visible content is rendered. Common elements found within the<head> include:
```

```html
<title>: The title of the page, shown in the browser tab and search engine results.
```

```html
<meta>: Metadata such as character encoding, viewport settings, and page description.
```

```html
<link>: Links to external resources, most commonly CSS stylesheets.
```

```html
<script>: Can be used to include JavaScript, though it is often placed elsewhere for performance reasons.
```

```html
<style>: For including internal CSS.
```

```html
The <body> Element: This section contains all the content that is visible to the user on the web page.1 This includes text, headings, paragraphs, images, videos, links, forms, and all other structural components that form the user interface. There can only be one<body> element in a document.15
```

```html
<!DOCTYPE html><html lang="en"><head> <meta charset="UTF-8">    <title>Head vs. Body</title>    <link rel="stylesheet" href="styles.css"></head><body> <h1>Welcome to the Page</h1>    <p>This text is visible to the user.</p></body></html>
```
