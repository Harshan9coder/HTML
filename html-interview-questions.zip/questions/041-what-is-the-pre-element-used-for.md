# 41. What is the <pre> element used for?

```html
The <pre> (preformatted text) element is used to display a block of text in which whitespace is preserved exactly as it is written in the HTML source code.19 Normally, browsers collapse multiple whitespace characters into a single space. The
```

```html
<pre> tag overrides this behavior.
```

```html
It is most commonly used for displaying computer code, poetry, or ASCII art, where indentation and line breaks are significant to the meaning and presentation of the content. Browsers typically render the content of a <pre> tag in a monospaced font. For marking up code, it is best practice to wrap the code itself in a <code> tag inside the <pre> tag for added semantic clarity.
```

```html
<pre><code>function greet(name) {  return `Hello, ${name}!`;}console.log(greet('World'));</code></pre>
```
