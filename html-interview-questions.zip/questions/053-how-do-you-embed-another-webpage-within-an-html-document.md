# 53. How do you embed another webpage within an HTML document?

```html
Another webpage or an external piece of content (like a map or a YouTube video) can be embedded into an HTML document using the <iframe> (inline frame) element.4
```

```html
The <iframe> creates a nested browsing context, effectively loading a separate HTML document within a rectangular region of the current page. The src attribute specifies the URL of the page to embed. The width and height attributes can be used to control the size of the frame.
```

```html
It is important to be aware of security implications when using <iframe>s, such as clickjacking. The sandbox attribute can be used to apply a set of restrictions to the content within the frame.
```

```html
<h2>Embedded Content</h2><iframe src="https://www.openstreetmap.org/export/embed.html?bbox=-0.1,51.5,-0.09,51.51"        width="600"        height="450"        style="border:0;"        allowfullscreen=""        loading="lazy"></iframe>
```
