# 72. How do you create a radio button group?

```html
To create a group of radio buttons where only one option can be selected, all the <input type="radio"> elements in the group must share the same name attribute. The value attribute for each radio button should be unique, as this is the value that will be submitted to the server if that option is selected.
```

```html
<fieldset>    <legend>Choose your favorite language:</legend>    <input type="radio" id="html" name="language" value="html">    <label for="html">HTML</label><br>    <input type="radio" id="css" name="language" value="css">    <label for="css">CSS</label><br>    <input type="radio" id="js" name="language" value="javascript">    <label for="js">JavaScript</label></fieldset>
```
