# 16. What is semantic HTML?

Semantic HTML is the practice of using HTML markup to reinforce the meaning and structure of the information in a webpage, rather than simply defining its presentation or appearance.1 It involves choosing the HTML element that best describes the content it contains.

```html
For example, using <h1> for the main page heading, <p> for a paragraph, and <li> for a list item are all examples of semantic markup. In contrast, using a <div> for everything and relying solely on CSS classes to describe content (e.g., <div class="main-heading">) is non-semantic. While it might look the same visually, it lacks the intrinsic meaning that semantic tags provide.
```

```html
<div class="header">My Website</div><div class="nav">    <span class="nav-item">Home</span>    <span class="nav-item">About</span></div><header>    <h1>My Website</h1></header><nav>    <ul>        <li><a href="/">Home</a></li>        <li><a href="/about">About</a></li>    </ul></nav>
```
