# 67. How do you group related form controls?

```html
Related form controls can be grouped together using the <fieldset> element. The <legend> element provides a caption or title for the group.7
```

```html
Grouping controls this way is beneficial for both visual organization and accessibility. Visually, browsers typically draw a box around the <fieldset>. For screen reader users, the <legend> text is announced when the user focuses on the first control within the group, providing context for the entire set of related inputs (e.g., "Shipping Address").
```

```html
<fieldset>    <legend>Contact Information</legend>    <label for="name">Name:</label>    <input type="text" id="name" name="name">    <label for="email">Email:</label>    <input type="email" id="email" name="email"></fieldset>
```
