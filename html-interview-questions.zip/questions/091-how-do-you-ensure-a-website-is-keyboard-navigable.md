# 91. How do you ensure a website is keyboard navigable?

Keyboard navigability is essential for users with motor disabilities who cannot use a mouse, as well as for power users and screen reader users.11 The key principles are:

```html
Use Native Interactive Elements: Use <a>, <button>, <input>, and other native interactive elements wherever possible. These elements are keyboard-focusable by default.
```

Logical Tab Order: Ensure the order in which elements receive focus when pressing the Tab key is logical and follows the visual flow of the page. This is usually achieved naturally by having a logical source order in the HTML.

Visible Focus Indicator: Never remove the browser's default focus outline (e.g., with outline: none;) without providing a clear and high-contrast alternative. Users need to be able to see which element currently has focus.

```html
Custom Controls: If you create custom interactive components (e.g., from <div>s), you must make them focusable by adding tabindex="0" and add the necessary JavaScript event listeners to handle keyboard events (like Enter and Space for activation).
```
