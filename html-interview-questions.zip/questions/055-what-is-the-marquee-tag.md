# 55. What is the <marquee> tag?

```html
The <marquee> tag is a non-standard, deprecated HTML element used to create a scrolling area of text or images.5 It was popular in the early days of the web but is now considered obsolete.
```

It should not be used in modern web development for several reasons:

It is not part of the W3C HTML standard.

It presents accessibility issues, as moving text can be difficult for people with cognitive disabilities to read and for screen readers to process.

It is a presentational element, and its functionality can be better and more accessibly replicated using CSS animations or JavaScript.
