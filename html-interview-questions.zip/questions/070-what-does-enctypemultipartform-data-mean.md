# 70. What does enctype="multipart/form-data" mean?

```html
The enctype attribute of a <form> element specifies how the form data should be encoded when submitting it to the server. The default value is application/x-www-form-urlencoded.
```

```html
However, when a form includes an <input type="file"> for file uploads, the enctype must be set to multipart/form-data.13 This encoding method does not encode the data and instead sends the form data in multiple parts, with one part for each form control and a separate part for the file content itself. This is necessary to handle the binary data of the uploaded file.
```

```html
<form action="/upload" method="post" enctype="multipart/form-data">    <label for="profile-pic">Upload a profile picture:</label>    <input type="file" id="profile-pic" name="picture">    <button type="submit">Upload</button></form>
```
