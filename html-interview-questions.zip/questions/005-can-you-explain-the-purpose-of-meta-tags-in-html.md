# 5. Can you explain the purpose of <meta> tags in HTML?

```html
Meta tags (<meta>) provide structured metadata about an HTML document.1 This information is not displayed on the page itself but is machine-readable and used by browsers, search engines, and other web services.7 Key meta tags include:
```

charset: Specifies the character encoding for the document. UTF-8 is the universal standard and is essential for ensuring text displays correctly across all languages and symbols.1

```html
Example: <meta charset="UTF-8">
```

viewport: This is critical for responsive web design. It tells the browser how to control the page's dimensions and scaling, ensuring the site looks good on all devices, from desktops to mobile phones.1

```html
Example: <meta name="viewport" content="width=device-width, initial-scale=1.0">
```

description: Provides a brief summary of the page's content. Search engines often use this description in their search results snippets, making it vital for SEO.1

```html
Example: <meta name="description" content="An in-depth guide to HTML interview questions.">
```

author: Specifies the author of the document.

```html
Example: <meta name="author" content="John Doe">
```

Open Graph & Twitter Cards: These are specialized meta tags used by social media platforms (like Facebook and X, formerly Twitter) to create rich previews when a link to the page is shared.

```html
<head>    <meta charset="UTF-8">    <meta name="viewport" content="width=device-width, initial-scale=1.0">    <meta name="description" content="This page explains the purpose of meta tags.">    <meta name="author" content="Web Development Experts"></head>
```
