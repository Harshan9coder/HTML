# 32. How do you create a paragraph and a line break?

```html
Paragraphs are created with the <p> tag. This is a block-level element that groups related sentences and is the most common way to structure blocks of text.1 Browsers automatically add some vertical space (margin) before and after each paragraph.
```

```html
A line break is created with the <br> tag. This is a void element used to force a line break within a block of text, without starting a new paragraph.2 It should be used sparingly, typically only when the division of lines is semantically important, such as in poetry or mailing addresses. It should not be used to create vertical space between elements; CSS margins and padding are the correct tools for that purpose.
```

```html
<p>This is a full paragraph of text. It will be separated from other paragraphs by a margin.</p><p>This is a second paragraph.</p><p>123 Web Dev Lane<br>   Codeville, HTML 54321</p>
```
