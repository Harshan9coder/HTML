# 88. What is the role of the alt attribute for accessibility?

```html
The alt attribute on an <img> tag provides a text alternative for the image.2 This is arguably one of the most critical and fundamental aspects of web accessibility.
```

For a user with a visual impairment using a screen reader, the alt text is read aloud, describing the content and function of the image. Without it, the user has no way of knowing what information the image conveys. A well-written alt attribute provides an equivalent experience for non-visual users. If an image is purely decorative, it should have an empty alt attribute (alt="") to signal to screen readers that it can be safely ignored.
