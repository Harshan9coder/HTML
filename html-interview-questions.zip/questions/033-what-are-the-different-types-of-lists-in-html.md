# 33. What are the different types of lists in HTML?

HTML provides three types of lists for structuring content, each with a specific semantic purpose.1

```html
Unordered List (<ul>): Used for a collection of items where the order does not matter. Browsers typically render these items with bullet points. Each item in the list is defined by an <li> (list item) tag.
```

```html
Ordered List (<ol>): Used for a collection of items where the order is significant (e.g., a list of steps in a recipe or a ranked list). Browsers typically render these items with numbers. Each item is also defined by an <li> tag.
```

```html
Description List (<dl>): Used for a list of terms and their corresponding descriptions (like a glossary or dictionary). It consists of three parts:
```

```html
<dl>: The description list container.
```

```html
<dt>: The description term.
```

```html
<dd>: The description details.
```

```html
<ul>    <li>Apples</li>    <li>Oranges</li>    <li>Bananas</li></ul><ol>    <li>First, gather your ingredients.</li>    <li>Next, mix them together.</li>    <li>Finally, bake for 30 minutes.</li></ol><dl>    <dt>HTML</dt>    <dd>HyperText Markup Language</dd>    <dt>CSS</dt>    <dd>Cascading Style Sheets</dd></dl>
```
