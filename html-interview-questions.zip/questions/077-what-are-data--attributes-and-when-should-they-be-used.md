# 77. What are data-* attributes and when should they be used?

data-* attributes are a standardized way to store custom, private data directly on an HTML element.1 The attribute name must start with

data-, followed by at least one character.

Their primary purpose is to store extra information that is relevant to the page's scripts but is not intended for display. This data can then be easily accessed and manipulated using JavaScript via the dataset property of the element object.

This is particularly useful for associating metadata with elements without resorting to non-standard attributes or misusing class or id. For example, you could store a product's ID or a user's role directly on an element.

```html
<div id="user-card" data-user-id="987" data-role="editor">    John Doe</div><script>    const card = document.getElementById('user-card');    const userId = card.dataset.userId; // "987"    const userRole = card.dataset.role;   // "editor"    console.log(`User ${userId} has the role of ${userRole}.`);</script>
```
