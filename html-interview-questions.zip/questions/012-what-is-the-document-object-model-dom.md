# 12. What is the Document Object Model (DOM)?

The Document Object Model (DOM) is a programming interface for web documents.4 When a web browser loads an HTML document, it creates an in-memory, tree-like representation of that document's structure. This tree is the DOM. Each node in the tree represents a part of the document, such as an element, an attribute, or a piece of text.

The DOM is not the HTML source code itself; it is a live, dynamic model of the page. It serves as the crucial bridge between the static HTML document and scripting languages like JavaScript. Using the DOM, JavaScript can:

Access and select any element on the page.

Modify the structure, style, and content of the page.

Create and delete elements.

React to user events (like clicks or key presses).

Essentially, the DOM makes the web page interactive. Any change made to the DOM by a script is immediately reflected in what the user sees in the browser.

```html
<!DOCTYPE html><html><body>    <h1 id="title">Hello World</h1></body></html><script>    // Using the DOM to access an element and change its content    const heading = document.getElementById('title');    heading.textContent = 'Hello DOM!';</script>
```
