# 57. How do you add a video background to an HTML element?

```html
Creating a video background involves using the HTML5 <video> element and positioning it behind other content with CSS.2
```

```html
HTML Structure: Place a <video> element within a container div. The video should have the autoplay, loop, and muted attributes. The muted attribute is often necessary for autoplay to work in modern browsers.
```

CSS Styling: Use CSS to position the video absolutely within its container, set its width and height to cover the entire container, and use z-index: -1 to place it behind the other content. The object-fit: cover property is useful for ensuring the video covers the area without being distorted.

```html
<style>   .video-container {        position: relative;        height: 100vh;        width: 100%;        overflow: hidden;        color: white;        text-align: center;    }    #background-video {        position: absolute;        top: 50%;        left: 50%;        min-width: 100%;        min-height: 100%;        width: auto;        height: auto;        z-index: -1;        transform: translateX(-50%) translateY(-50%);        background-size: cover;    }   .content {        position: relative;        z-index: 1;        padding-top: 20vh;    }</style><div class="video-container">    <video autoplay muted loop id="background-video">        <source src="background.mp4" type="video/mp4">    </video>    <div class="content">        <h1>Welcome to Our Site</h1>        <p>Experience the motion.</p>    </div></div>
```
