# 60. How do you add a favicon to your website?

```html
A favicon (favorite icon) is a small icon displayed in the browser tab, bookmarks bar, and other places. It is added to a website using a <link> tag in the <head> section of the HTML document.19
```

The rel attribute should be set to icon, and the href attribute should point to the location of the icon file. While historically .ico was the standard format, modern browsers support other formats like PNG, GIF, and SVG. It is good practice to also specify the type of the image file.

```html
<head>    <title>My Website</title>    <link rel="icon" href="/favicon.ico" type="image/x-icon">    <link rel="icon" href="/favicon.png" type="image/png"></head>
```

Section V: Interactive Elements - Forms & User Input

This section provides an in-depth look at HTML forms, the primary mechanism for collecting user input. HTML5 forms represent a significant stride in shifting validation logic from the server to the client, improving user experience and reducing unnecessary server load. This demonstrates a core principle of modern web development: progressive enhancement. The browser provides a baseline level of functionality and validation, creating a faster, more responsive, and user-friendly interface, while server-side validation remains essential for security. An interviewer asking about these features is testing a candidate's understanding of modern UX principles.
