# 66. What are <textarea>, <select>, and <option> elements used for?

These are other essential form controls for different types of user input.2

```html
<textarea>: Defines a multi-line text input control. Unlike the <input type="text">, it can hold an unlimited number of characters, and the text can wrap. The size of the text area can be specified by the rows and cols attributes, or more flexibly with CSS.
```

```html
<select>: Creates a dropdown list. It acts as a container for a list of <option> elements.
```

```html
<option>: Defines an option in a <select> list. The text between the <option> tags is what the user sees, and the value attribute specifies the data that is sent to the server when that option is selected.
```

```html
<label for="comments">Comments:</label><textarea id="comments" name="comments" rows="4" cols="50"></textarea><label for="country">Country:</label><select id="country" name="country">    <option value="us">United States</option>    <option value="ca">Canada</option>    <option value="mx">Mexico</option></select>
```
