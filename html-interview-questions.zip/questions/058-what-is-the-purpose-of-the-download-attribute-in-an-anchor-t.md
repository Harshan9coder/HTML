# 58. What is the purpose of the download attribute in an anchor tag?

```html
The download attribute, when added to an <a> tag, instructs the browser to download the linked URL instead of navigating to it.
```

When a user clicks on the link, a "Save As" dialog will appear, prompting them to save the file locally. The value of the download attribute can be used to suggest a filename for the downloaded file. If the value is empty, the browser will use the original filename. This is particularly useful for forcing the download of file types that the browser would normally try to display, such as images or PDF files.

```html
<a href="/images/report.pdf" download>Download the Report</a><a href="/images/report.pdf" download="annual-report.pdf">Download the Annual Report</a>
```
