# 87. How does semantic HTML improve accessibility?

Semantic HTML is the foundation of an accessible website.11 As discussed previously, assistive technologies like screen readers do not see the visual layout of a page; they interpret the DOM. Semantic elements provide a machine-readable structure that these technologies can use to convey meaning and provide navigational shortcuts.

```html
Headings (<h1>-<h6>) create a document outline.
```

```html
Landmark elements (<nav>, <main>, <header>, <footer>) define the major regions of a page, allowing users to jump directly to the content they need.
```

```html
List elements (<ul>, <ol>) inform the user that they are about to hear a list of related items and how many items are in the list.
```

```html
Form elements (<label>, <fieldset>) create clear associations between text and input controls.
```

```html
Using a <div> for everything forces a screen reader user to navigate the page linearly, without any context or shortcuts, making the experience frustrating and inefficient.
```
