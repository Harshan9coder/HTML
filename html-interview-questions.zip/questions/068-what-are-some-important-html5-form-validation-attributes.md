# 68. What are some important HTML5 form validation attributes?

HTML5 introduced several attributes that allow for declarative, client-side validation directly in the markup, reducing the need for JavaScript.2

required: A boolean attribute that specifies that an input field must be filled out before submitting the form.

placeholder: Provides a short hint or example text that is displayed in the input field before the user enters a value.

pattern: Specifies a regular expression that the input field's value is checked against. This is powerful for validating complex formats like phone numbers or postal codes.

min and max: Specify the minimum and maximum values for an input of type number, range, or date.

step: Specifies the legal number intervals for an input of type number or range.

readonly: A boolean attribute that specifies that an input field is read-only (cannot be changed) but its value is still submitted with the form.

disabled: A boolean attribute that specifies that an input field should be disabled. A disabled input is unusable and un-clickable, and its value is not submitted with the form.
