# 10. How do you add a comment in HTML and why are they used?

HTML comments are added using the syntax ``.1 Anything between these delimiters will not be rendered by the browser or processed by parsers.

Comments are a crucial tool for developers and serve several purposes 1:

Documentation: To explain complex or non-obvious parts of the markup, making the code easier for other developers (or a future self) to understand.

Instructions: To leave notes or reminders for team members about tasks to be completed.

Debugging: To temporarily "comment out" a block of HTML to see how the page renders without it, which is a common technique for isolating issues.

Organization: To add labels that visually separate large sections of code, improving readability.

Best practices for commenting include writing clear, concise comments that explain the "why" behind the code, not just the "what," and ensuring comments are kept up-to-date as the code evolves.

```html
<header>    <h1>Website Title</h1></header>
```
