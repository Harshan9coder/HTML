# 8. What is the difference between an HTML element, tag, and attribute?

These three terms are the fundamental building blocks of HTML, but they are not interchangeable.2

```html
Tag: An HTML tag is the markup syntax used to denote the start and end of an element. It consists of a keyword enclosed in angle brackets. For example, <p> is a start tag and </p> is an end tag.5
```

```html
Element: An HTML element is the complete component, consisting of the start tag, the content, and the end tag.5 For example,<p>This is some text.</p> is a paragraph element. Some elements, known as void elements, are self-contained and do not have content or an end tag (e.g., <img>).
```

```html
Attribute: An attribute provides additional information about an element and is always specified in the start tag.4 Attributes come in name/value pairs, likename="value". For example, in <a href="https://example.com">Click me</a>, href is an attribute of the <a> element, and its value is the URL.
```

```html
<p class="info-text">This is a paragraph.</p>
```
