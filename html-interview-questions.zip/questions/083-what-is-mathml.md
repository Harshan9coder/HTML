# 83. What is MathML?

MathML stands for Mathematical Markup Language. It is an XML-based language used to describe mathematical notation and structure for display on web pages.10

With HTML5, MathML can be embedded directly into HTML documents, allowing browsers to render complex mathematical formulas and equations semantically. This is a significant improvement over using images to display equations, as MathML is accessible to screen readers and can be styled with CSS.

```html
<p>The quadratic formula is:</p><math>    <mi>x</mi>    <mo>=</mo>    <mfrac>        <mrow>            <mo form="prefix">−</mo>            <mi>b</mi>            <mo>±</mo>            <msqrt>                <msup>                    <mi>b</mi>                    <mn>2</mn>                </msup>                <mo>−</mo>                <mn>4</mn>                <mi>a</mi>                <mi>c</mi>            </msqrt>        </mrow>        <mrow>            <mn>2</mn>            <mi>a</mi>        </mrow>    </mfrac></math>
```
