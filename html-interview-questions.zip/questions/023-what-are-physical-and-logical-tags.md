# 23. What are physical and logical tags?

This is a broader way of categorizing the distinction between presentational and semantic tags.10

```html
Physical Tags: These are tags that define the visual appearance of the text. They are presentational in nature. Examples include <b> (bold), <i> (italic), <u> (underline), and <font> (deprecated). They tell the browser how to display the content.
```

```html
Logical Tags: These are tags that define the semantic meaning or structure of the content. They describe what the content is. Examples include <strong> (strong importance), <em> (emphasis), <code> (a piece of computer code), and <address> (contact information).
```

Modern web development standards strongly favor the use of logical tags over physical tags. Styling should be handled by CSS, while HTML should focus on describing the content's meaning and structure.
