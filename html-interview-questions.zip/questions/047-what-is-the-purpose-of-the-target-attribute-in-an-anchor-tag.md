# 47. What is the purpose of the target attribute in an anchor tag?

The target attribute specifies where to open the linked document.2 The most common values are:

_self (Default): Opens the document in the same window or tab where it was clicked.

_blank: Opens the document in a new window or tab. This is frequently used for links to external sites to keep the user on the original site.

```html
_parent: Opens the document in the parent frame (used with <iframe>s).
```

_top: Opens the document in the full body of the window, breaking out of any frames.

When using target="_blank", it is a critical security best practice to also include rel="noopener noreferrer".

noopener prevents the new page from being able to access the original page's window object via window.opener, which prevents a potential security vulnerability.

noreferrer prevents the browser from sending the Referer HTTP header to the new page, which can be a privacy consideration.

```html
<a href="https://externalsite.com" target="_blank" rel="noopener noreferrer">    Visit External Site</a>
```
