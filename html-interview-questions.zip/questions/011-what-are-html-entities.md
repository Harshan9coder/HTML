# 11. What are HTML entities?

HTML entities are reserved strings of text that are used to display characters that have special meaning in HTML or are not easily typed on a standard keyboard.4 An entity starts with an ampersand (

&) and ends with a semicolon (;).

They are necessary for two primary reasons:

To display reserved characters: Characters like < and > are part of the HTML syntax itself. To display them as literal text on the page, they must be "escaped" using their corresponding entities.

To display special symbols: Entities provide a way to display symbols like the copyright sign (©), the registered trademark symbol (®), or mathematical symbols that may not be present on all keyboards.

Common HTML entities include:

< for the less-than sign (<)

> for the greater-than sign (>)

& for the ampersand (&)

" for a double quote (")

© for the copyright symbol (©)

for a non-breaking space, which prevents an automatic line break at its position.

```html
<p>To write the <h1> tag, you must use <h1>.</p><p>Copyright © 2025. All rights reserved.</p>
```
