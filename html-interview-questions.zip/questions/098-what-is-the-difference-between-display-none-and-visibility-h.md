# 98. What is the difference between display: none and visibility: hidden?

These are two CSS properties used to hide elements, but they do so in fundamentally different ways, which is a common interview question that bridges HTML and CSS knowledge.5

visibility: hidden:

The element is made invisible, but it still occupies its space in the document layout. It's as if the element is transparent.

Child elements can be made visible again by setting visibility: visible on them.

display: none:

The element is completely removed from the document flow. It takes up no space, and the layout reflows as if the element never existed.

The element and all of its descendants are hidden and cannot be made visible by changing the visibility property on a child.

The HTML hidden attribute is generally equivalent to applying display: none; via CSS.
