# 39. What is the difference between cellpadding and cellspacing?

```html
These are older, presentational attributes for the <table> element that have been deprecated in HTML5 in favor of CSS properties.15
```

```html
cellspacing: Defines the space between adjacent cells in a table. In CSS, this is controlled by the border-spacing property on the <table> element.
```

```html
cellpadding: Defines the space between the content of a cell and the cell's border. In CSS, this is controlled by the padding property on <td> and <th> elements.
```

Understanding their historical purpose is useful, but modern development practice dictates that all styling, including table spacing and padding, should be managed with CSS.
