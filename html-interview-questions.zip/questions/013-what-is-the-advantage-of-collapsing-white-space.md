# 13. What is the advantage of collapsing white space?

In HTML, browsers treat any sequence of one or more whitespace characters (spaces, tabs, newlines) as a single space.5 This behavior is known as "collapsing white space."

The primary advantage of this feature is that it gives developers the freedom to format their HTML source code for maximum readability without affecting the final rendered output.15 Developers can use indentation and line breaks to neatly structure their code and reflect the nesting of elements, making the markup much easier to read, understand, and maintain. If whitespace were not collapsed, this kind of source code formatting would result in large, unwanted gaps in the rendered page.

```html
<p>    This text    is formatted    for readability in the source code.</p><p>This text is formatted for readability in the source code.</p>
```
