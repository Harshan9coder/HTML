# 27. What is the difference between id and class attributes?

id and class are global attributes used to provide identifiers for elements, but they have a fundamental difference in their uniqueness constraint.5

id (Identifier):

The id attribute specifies a unique identifier for an element within the entire HTML document.

Each id value must be used only once per page.

```html
It is primarily used as a hook for JavaScript to select a specific, single element (document.getElementById()) or as a target for internal page links (fragment identifiers, e.g., <a href="#section1">).
```

class:

The class attribute specifies one or more class names for an element.

The same class name can be used on multiple elements across the page.

An element can also have multiple class names, separated by spaces.

It is primarily used as a hook for CSS to apply the same styles to a group of elements or for JavaScript to select a group of elements (document.getElementsByClassName()).

In summary: Use id when you need to uniquely identify one element. Use class when you want to group multiple elements to share styling or behavior.

```html
<h1 id="main-title">My Page</h1><p class="highlight">This is important text.</p><ul>    <li class="highlight">This is an important item.</li></ul>
```
