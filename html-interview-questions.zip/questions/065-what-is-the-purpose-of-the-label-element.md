# 65. What is the purpose of the <label> element?

```html
The <label> element is essential for form accessibility. It provides a human-readable caption for a form control.15
```

```html
A <label> is programmatically associated with its corresponding <input> (or other form control) in one of two ways:
```

```html
Wrapping: The <input> is placed inside the <label> element.
```

```html
Using for and id: The <label> has a for attribute whose value is the same as the id of the <input> element. This is the more robust and common method.
```

This association provides two key benefits:

Accessibility: Screen readers will read the label text when the user focuses on the input field, providing context for what information should be entered.

Usability: On all devices, a user can click on the label text to focus on or activate the corresponding input field. This is especially helpful for small targets like checkboxes and radio buttons.

A form without properly associated labels is not accessible.

```html
<label for="user-name">Name:</label><input type="text" id="user-name" name="name"><label>    <input type="checkbox" name="subscribe">    Subscribe to newsletter</label>
```
