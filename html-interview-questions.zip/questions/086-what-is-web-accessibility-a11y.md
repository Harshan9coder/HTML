# 86. What is Web Accessibility (A11y)?

Web Accessibility is the inclusive practice of ensuring there are no barriers that prevent interaction with, or access to, websites on the World Wide Web by people with physical disabilities, situational disabilities, and socio-economic restrictions on bandwidth and speed.7

When sites are correctly designed, developed, and edited, all users have equal access to information and functionality. This means creating content that can be navigated and understood by people who may be using assistive technologies like screen readers, screen magnifiers, or voice recognition software, as well as those who can only use a keyboard for navigation.
