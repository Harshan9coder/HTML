# 28. Are HTML tags and elements the same thing?

No, they are distinct concepts, though often used interchangeably in casual conversation.2

```html
An HTML tag is the syntax used to mark the beginning and end of an element (e.g., <h1> and </h1>).
```

```html
An HTML element is the entire unit, which includes the start tag, the content inside, and the end tag (e.g., <h1>Main Heading</h1>).
```

```html
For void elements like <img>, the element consists of just the single tag and its attributes.
```
