# 44. What would happen if there is no text between HTML tags?

```html
If there is no content between the start and end tags of a standard element (like <p></p> or <div></div>), the element will still exist in the DOM, but it will typically have no height and thus will not be visible on the page.5 It will occupy zero space in the document flow. However, it can still be styled with CSS (e.g., given a height, border, or background color) or manipulated with JavaScript.
```

```html
For void elements like <img>, which don't have closing tags, the concept doesn't apply as they cannot contain text content by definition.18
```

```html
<p></p><div style="height: 50px; width: 50px; border: 1px solid black;"></div>
```
