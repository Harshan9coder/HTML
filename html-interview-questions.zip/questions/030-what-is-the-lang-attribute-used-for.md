# 30. What is the lang attribute used for?

The lang global attribute is used to specify the language of an element's content.1 It is most commonly used on the root

```html
<html> element to declare the primary language for the entire page.
```

However, it can also be used on any other element to indicate that a specific part of the content is in a different language. This is important for:

Accessibility: It signals to screen readers to switch language profiles for correct pronunciation.

Search Engines: It helps search engines correctly index content in different languages.

Browser Behavior: It can affect hyphenation, spell-checking, and translation services offered by the browser.

```html
<html lang="en"><body>    <p>This paragraph is in English.</p>    <p lang="fr">Ce paragraphe est en français.</p></body></html>
```

Section III: Structuring Content - Text, Lists, and Tables

This section focuses on the workhorse elements for organizing the majority of web content: text, lists, and tabular data. The emphasis will be on correct structural usage and accessibility, ensuring that content is not only visually organized but also logically coherent for all users and machines.
