# 52. How do you embed audio and video in HTML5?

```html
HTML5 introduced the native <audio> and <video> elements, which revolutionized media embedding on the web by eliminating the need for third-party plugins like Flash.4
```

```html
<audio> Element: Used to embed sound content.
```

```html
<video> Element: Used to embed video content.
```

Both elements share common attributes and features:

src: Specifies the path to the media file.

controls: A boolean attribute that, if present, displays the browser's default playback controls (play/pause, volume, etc.).

autoplay: A boolean attribute to make the media play automatically on load (Note: most modern browsers block autoplay with sound unless the user has interacted with the page first).

loop: A boolean attribute to make the media loop continuously.

```html
<source> Element: To ensure cross-browser compatibility, it is best practice to provide multiple media formats using nested <source> elements. The browser will use the first format it supports.
```

```html
<video controls width="640" height="360">    <source src="movie.mp4" type="video/mp4">    <source src="movie.webm" type="video/webm">    Your browser does not support the video tag.</video><audio controls>    <source src="sound.mp3" type="audio/mpeg">    <source src="sound.ogg" type="audio/ogg">    Your browser does not support the audio element.</audio>
```
