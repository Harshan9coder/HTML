# 64. What are some of the new input types introduced in HTML5?

HTML5 added several new input types that provide better user experience, especially on mobile devices, and enable built-in browser validation.3

email: For email addresses. The browser may provide validation to ensure the input is a valid email format.

url: For web addresses.

tel: For telephone numbers. Mobile browsers may display a numeric keypad.

number: For numerical values. Provides spinner controls and can be constrained with min, max, and step attributes.

date: Provides a date picker interface.

color: Provides a color picker interface.

range: A slider control for selecting a value within a range.

search: A text field specifically for search terms.

Using these types allows the browser to provide a more appropriate user interface and perform client-side validation without requiring JavaScript.

```html
<form action="/submit" method="post">    <label for="email-addr">Email:</label>    <input type="email" id="email-addr" name="email" required>    <label for="quantity">Quantity (1-5):</label>    <input type="number" id="quantity" name="quantity" min="1" max="5">    <label for="appt-date">Appointment Date:</label>    <input type="date" id="appt-date" name="appointment_date">    <button type="submit">Submit</button></form>
```
