# 1. What does HTML stand for and what is its purpose?

HTML stands for HyperText Markup Language.1 It is the standard language used to create and structure the content of web pages.4 Its purpose is not to program logic but to "mark up" or describe the content's structure and semantic meaning.

HyperText refers to the ability to create links that connect web pages to one another, forming the interconnected "web" of information.4

Markup Language refers to the system of using tags to define elements, such as headings, paragraphs, images, and lists, which tells the browser how to organize and display the content.3

Essentially, HTML serves as the skeleton of a webpage, providing the foundational structure upon which styling (CSS) and interactivity (JavaScript) are applied.

```html
<!DOCTYPE html><html><head>    <title>Page Title</title></head><body>    <h1>This is a Heading</h1>    <p>This is a paragraph of text.</p>    <a href="https://example.com">This is a link.</a></body></html>
```
