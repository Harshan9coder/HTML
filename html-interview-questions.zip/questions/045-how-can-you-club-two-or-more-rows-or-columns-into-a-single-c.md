# 45. How can you club two or more rows or columns into a single cell in a table?

```html
This is achieved using the rowspan and colspan attributes on a <td> or <th> element, as detailed in question 37.15
```

colspan merges a cell horizontally with cells to its right.

rowspan merges a cell vertically with cells in the rows below it.

```html
When using these attributes, you must omit the corresponding <td> or <th> elements from the subsequent columns or rows to avoid breaking the table structure.
```

```html
<table border="1">    <tr>        <td>Cell 1.1</td>        <td colspan="2">Cell 1.2 (spans 2 columns)</td>    </tr>    <tr>        <td rowspan="2">Cell 2.1 (spans 2 rows)</td>        <td>Cell 2.2</td>        <td>Cell 2.3</td>    </tr>    <tr>        <td>Cell 3.2</td>        <td>Cell 3.3</td>    </tr></table>
```

Section IV: Linking & Embedding Media

This section covers how to connect documents and embed rich media. The evolution of media handling in HTML5 reflects a major shift towards reducing dependency on third-party plugins (like Flash) and prioritizing native browser performance and accessibility. A developer's knowledge of these modern media tags is a proxy for their understanding of the contemporary web development landscape, which emphasizes performance optimization, responsive design, and a standardized, plugin-free user experience.
