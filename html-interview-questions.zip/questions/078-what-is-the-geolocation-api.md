# 78. What is the Geolocation API?

The HTML5 Geolocation API provides a way for web applications to retrieve the geographical location (latitude and longitude) of a user's device.10

For privacy reasons, the browser will always ask for the user's permission before sharing their location with a website. The API is accessed through the navigator.geolocation object. The primary method is getCurrentPosition(), which takes a success callback function, an optional error callback function, and optional position options.

This API is the foundation for location-aware web applications, such as mapping services, local search, and check-in features.

```html
<button id="find-me">Show my location</button><p id="location-info"></p><script>    const findMeButton = document.getElementById('find-me');    const locationInfo = document.getElementById('location-info');    findMeButton.addEventListener('click', () => {        if (!navigator.geolocation) {            locationInfo.textContent = 'Geolocation is not supported by your browser.';        } else {            locationInfo.textContent = 'Locating…';            navigator.geolocation.getCurrentPosition(success, error);        }    });    function success(position) {        const latitude  = position.coords.latitude;        const longitude = position.coords.longitude;        locationInfo.textContent = `Latitude: ${latitude}°, Longitude: ${longitude}°`;    }    function error() {        locationInfo.textContent = 'Unable to retrieve your location.';    }</script>
```
