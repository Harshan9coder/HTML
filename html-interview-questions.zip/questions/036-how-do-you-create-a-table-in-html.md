# 36. How do you create a table in HTML?

HTML tables are used to display tabular data in a structured grid of rows and columns. Creating an accessible and well-structured table involves several key elements.2

```html
<table>: The main container for the entire table.
```

```html
<thead>: (Optional but recommended) Groups the header content of the table.
```

```html
<tbody>: (Optional but recommended) Groups the main body content of the table.
```

```html
<tfoot>: (Optional but recommended) Groups the footer content of the table.
```

```html
<tr> (Table Row): Defines a row of cells in the table.
```

```html
<th> (Table Header): Defines a header cell. The content is typically bold and centered by default. It should be used for column and row titles.
```

```html
<td> (Table Data): Defines a standard data cell.
```

```html
<caption>: Provides a title or caption for the table, which is important for accessibility.
```

```html
Using <thead>, <tbody>, and <tfoot> provides semantic structure and allows browsers to scroll the table body independently of the header and footer.
```

```html
<table border="1">    <caption>Monthly Sales Figures</caption>    <thead>        <tr>            <th>Month</th>            <th>Sales</th>        </tr>    </thead>    <tbody>        <tr>            <td>January</td>            <td>$10,000</td>        </tr>        <tr>            <td>February</td>            <td>$12,000</td>        </tr>    </tbody>    <tfoot>        <tr>            <td>Total</td>            <td>$22,000</td>        </tr>    </tfoot></table>
```
