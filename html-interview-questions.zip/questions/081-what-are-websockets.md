# 81. What are WebSockets?

The WebSocket API is a technology that enables opening a two-way, interactive communication session between a user's browser and a server.10 With this API, you can send messages to a server and receive event-driven responses without having to poll the server for a reply.

Unlike traditional HTTP, which follows a request-response model, WebSockets provide a persistent, full-duplex connection. This means both the client and the server can send data to each other at any time, making it ideal for real-time applications such as:

Live chat applications

Multiplayer online games

Real-time data feeds (e.g., stock tickers, sports scores)

Collaborative editing tools
