# 80. What are Web Workers?

A Web Worker is a JavaScript script that runs in the background on a separate thread from the main browser UI thread.10

The main purpose of Web Workers is to allow long-running or computationally intensive tasks to be performed without freezing or slowing down the user interface. The main thread remains responsive to user interactions (like clicks and scrolling) while the worker thread performs the heavy lifting in the background.

Communication between the main thread and the worker thread is done via a system of messages. They cannot directly access or manipulate the DOM.

```javascript
// main.jsconst myWorker = new Worker('worker.js');myWorker.postMessage(); // Send data to the workermyWorker.onmessage = function(e) {    console.log('Result from worker:', e.data); // Receives data back from the worker}// worker.jsonmessage = function(e) {    const result = e.data * e.data;    postMessage(result); // Send the result back to the main thread}
```
