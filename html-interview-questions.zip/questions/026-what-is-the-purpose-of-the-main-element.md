# 26. What is the purpose of the main element?

```html
The <main> element represents the dominant, primary content of the <body> of a document.7 The content inside the
```

```html
<main> element should be unique to that document and should not include content that is repeated across multiple pages, such as sidebars, site navigation, headers, or footers.
```

```html
By definition, there must be only one <main> element in a document, and it must not be a descendant of an <article>, <aside>, <footer>, <header>, or <nav> element.
```

```html
Using <main> provides a powerful landmark for assistive technologies. It allows screen reader users to jump directly to the primary content of the page, bypassing repetitive navigation links and headers.
```

```html
<body>    <header>...</header>    <nav>...</nav>    <main>        <h1>Main Article Title</h1>        <p>This is the core content of the page...</p>    </main>    <footer>...</footer></body>
```
