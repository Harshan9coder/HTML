# 94. What is the difference between <script>, <script async>, and <script defer>?

```html
The async and defer attributes on the <script> tag provide powerful control over how and when external JavaScript files are loaded and executed, with significant performance implications. Their correct usage depends entirely on the script's dependencies.3
```

```html
<script> (Default): The browser pauses HTML parsing, fetches the script, executes it, and then resumes parsing. This is render-blocking.
```

```html
<script async>: The script is fetched in parallel with HTML parsing. As soon as the script is downloaded, HTML parsing is paused, and the script is executed. After execution, parsing resumes. Scripts may execute in any order, as soon as they are ready. This is useful for independent scripts, like analytics, that don't depend on the DOM or other scripts.
```

```html
<script defer>: The script is fetched in parallel with HTML parsing. The script is only executed after the HTML parsing is complete, just before the DOMContentLoaded event. defer scripts are guaranteed to execute in the order they appear in the HTML. This is the best choice for scripts that need to interact with the DOM.
```

The following table summarizes the behavior.13

Attribute

HTML Parsing

Script Fetching

Script Execution

```html
<script> (Default)
```

Paused during fetch & execution

Blocking

Immediately after fetch

<script async>

Continues during fetch; paused during execution

Parallel (non-blocking)

As soon as downloaded; order not guaranteed

<script defer>

Continues during fetch

Parallel (non-blocking)

After HTML parsing is complete; order guaranteed

Choosing the wrong attribute can lead to race conditions and execution errors. An interviewer asking this question is testing a candidate's deep understanding of the browser's rendering pipeline and their ability to write non-blocking, performant code.
