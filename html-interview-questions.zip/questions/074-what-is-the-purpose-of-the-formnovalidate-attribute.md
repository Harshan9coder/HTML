# 74. What is the purpose of the formnovalidate attribute?

```html
The formnovalidate is a boolean attribute that can be applied to a submit button (<input type="submit"> or <button type="submit">). When present, it specifies that the form should not be validated when submitted.2
```

This overrides the form's default validation behavior and any validation attributes on the input fields (like required or pattern). It is useful for implementing a "Save as Draft" feature, where you want to allow the user to save their progress without having to fill out the entire form correctly.

```html
<form action="/submit" method="post">    <label for="title">Title (required):</label>    <input type="text" id="title" name="title" required>    <button type="submit">Submit</button>    <button type="submit" formnovalidate>Save as Draft</button></form>
```
