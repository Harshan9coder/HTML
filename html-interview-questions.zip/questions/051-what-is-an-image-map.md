# 51. What is an image map?

An image map allows you to define clickable areas, or "hotspots," within a single image.5 Each hotspot can be linked to a different URL. This is created using a

```html
<map> element, which is associated with an <img> via the usemap attribute. Inside the <map>, <area> elements define the shape (rect, circle, poly), coordinates, and href for each clickable region.
```

Image maps are less common today, as CSS and JavaScript often provide more flexible and accessible solutions for creating complex interactive graphics. However, they can still be useful for certain applications, like geographical maps or diagrams.

```html
<img src="solar-system.png" alt="Planets of the solar system." usemap="#planetmap"><map name="planetmap">    <area shape="rect" coords="0,0,82,126" href="sun.html" alt="Sun">    <area shape="circle" coords="90,58,3" href="mercury.html" alt="Mercury">    <area shape="circle" coords="124,58,8" href="venus.html" alt="Venus"></map>
```
