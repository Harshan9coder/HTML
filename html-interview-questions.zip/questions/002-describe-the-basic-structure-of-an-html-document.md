# 2. Describe the basic structure of an HTML document.

A well-formed HTML document follows a consistent, hierarchical structure. This structure is essential for browsers to parse and render the page correctly.1 The primary components are:

<!DOCTYPE html>: A declaration that defines the document type.

```html
<html> Element: The root element that wraps all other content on the page.
```

```html
<head> Element: A container for metadata about the page.
```

```html
<body> Element: A container for all the visible content of the page.
```

```html
<!DOCTYPE html><html lang="en">    <head>        <meta charset="UTF-8">        <title>Document Title</title>    </head>    <body>        <h1>My First Web Page</h1>        <p>Content for the user to see.</p>    </body></html>
```
