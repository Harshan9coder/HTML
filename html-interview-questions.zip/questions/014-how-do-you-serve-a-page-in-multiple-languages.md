# 14. How do you serve a page in multiple languages?

Serving a page with content in multiple languages involves several layers of implementation, from the HTML markup to server-side logic.1

```html
Language Declaration (lang attribute): As mentioned earlier, the lang attribute on the <html> tag is the first step. It should be set to the language of the content being displayed (e.g., <html lang="es"> for Spanish).
```

```html
Alternate Language Links (hreflang): For SEO, it is crucial to tell search engines about the different language versions of a page. This is done using <link> tags with the hreflang attribute in the <head> section. Each link points to a URL for a specific language version of the current page.
```

Content Delivery: The server must be configured to deliver the correct language version to the user. This can be based on:

URL Structure: Using different URLs for each language (e.g., example.com/en/page and example.com/es/page). This is the recommended approach for SEO.

User Preference: Allowing the user to select their preferred language via a dropdown menu, with the choice stored in a cookie or localStorage.

Browser Settings: Detecting the user's preferred language from the Accept-Language HTTP header sent by their browser.

```html
<head>    <title>My Page</title>    <link rel="alternate" hreflang="en" href="https://example.com/en/page">    <link rel="alternate" hreflang="de" href="https://example.com/de/page">    <link rel="alternate" hreflang="x-default" href="https://example.com/en/page"></head>
```
