# 46. How do you create a hyperlink in HTML?

```html
Hyperlinks are the essence of the "hypertext" in HTML and are created using the anchor (<a>) tag.1 The most crucial attribute is
```

```html
href (hypertext reference), which specifies the destination URL of the link. The content between the opening <a> and closing </a> tags becomes the clickable text or element.
```

```html
<a href="https://www.w3.org/">Visit the World Wide Web Consortium</a><a href="/about.html">About Us</a><a href="#section-two">Jump to Section Two</a>
```
