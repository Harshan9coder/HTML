# 59. What is the difference between an absolute and a relative URL?

```html
The href attribute in an <a> tag or the src attribute in an <img> tag can take either an absolute or a relative URL.
```

Absolute URL: This is a full web address that includes the protocol (http:// or https://), domain name, and path. It points to a specific location on the web, regardless of the location of the current page. Absolute URLs are used for linking to external websites.

Relative URL: This is a partial address that is relative to the current page's URL. It does not include the protocol or domain name. Relative URLs are used for linking to other pages or resources within the same website. This makes the site more portable, as the links will not break if the domain name changes.

```html
<a href="https://www.mozilla.org/">Mozilla Homepage</a><a href="about.html">About Us</a><img src="images/logo.png" alt="Logo">
```
