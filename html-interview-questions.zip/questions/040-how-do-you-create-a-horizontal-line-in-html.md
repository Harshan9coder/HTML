# 40. How do you create a horizontal line in HTML?

```html
A horizontal line, representing a thematic break or a separation between sections of content, is created using the <hr> (horizontal rule) tag.7 It is a void element, so it does not require a closing tag.
```

```html
Semantically, <hr> should be used to indicate a shift in topic or a transition between different subjects within a piece of content. It should not be used purely for decorative purposes; for visual lines, CSS borders are the more appropriate tool.
```

```html
<p>This is the first topic of discussion. It covers several points related to web standards.</p><hr><p>This is the second topic. Now we shift our focus to server-side technologies.</p>
```
