# 9. What are void elements in HTML?

Void elements, also known as empty or self-closing elements, are HTML elements that cannot have any child nodes (i.e., they cannot contain any content or other elements).5 Because they are empty, they only have a start tag and do not require a closing tag.10

In HTML5, the trailing slash (/) is optional, but it is required in stricter syntaxes like XHTML. Common void elements include:

```html
<br>: A line break.
```

```html
<hr>: A thematic break (horizontal rule).
```

```html
<img>: An image.
```

```html
<input>: A form input control.
```

```html
<link>: A link to an external resource.
```

```html
<meta>: Metadata about the document.
```

```html
<p>This is the first line.<br>This is the second line.</p><hr><img src="logo.png" alt="Company Logo">
```
