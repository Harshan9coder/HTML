# 6. How do you link a CSS file to an HTML document?

```html
The standard and most effective way to apply styles to an HTML document is by linking to an external CSS stylesheet. This is done using the <link> tag placed within the <head> section of the document.1
```

```html
The <link> tag requires two key attributes:
```

rel="stylesheet": This attribute specifies the relationship between the HTML document and the linked file. In this case, it indicates that the file is a stylesheet.

href="path/to/styles.css": This attribute provides the path to the CSS file. The path can be relative (to the current HTML file) or absolute (a full URL).

```html
Placing the <link> tag in the <head> is a critical performance and user experience practice. The browser parses HTML from top to bottom. When it encounters a stylesheet link in the <head>, it begins fetching the CSS file in parallel while continuing to parse the rest of the HTML. This allows the browser to construct the CSS Object Model (CSSOM) alongside the Document Object Model (DOM). Having both ready early enables the browser to build the render tree and display the styled page to the user more quickly, avoiding a flash of unstyled content (FOUC).
```

```html
<!DOCTYPE html><html><head>    <title>Linking CSS</title>    <link rel="stylesheet" href="styles.css"></head><body>    <h1>This heading will be styled by styles.css</h1></body></html>
```
