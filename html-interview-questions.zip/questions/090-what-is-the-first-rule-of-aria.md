# 90. What is the first rule of ARIA?

The first and most important rule of ARIA is: If you can use a native HTML element or attribute with the semantics and behavior you require already built in, use it instead of repurposing an element and adding an ARIA role, state, or property to make it accessible.

```html
This principle reveals a crucial hierarchy of best practices. It is always better to use a native <button> element than to create a <div> and add role="button" and the necessary keyboard event listeners with JavaScript. The native element provides all the necessary semantics, keyboard focus behavior, and accessibility features for free, with less code and less room for error. ARIA should be seen as a patch for making non-semantic or custom-built components accessible, not as a replacement for proper semantic HTML. Overusing ARIA where native elements suffice is often a sign of a less experienced developer or a codebase that needs refactoring.
```

```html
<div role="button" tabindex="0" onclick="doSomething()">Click me</div><button onclick="doSomething()">Click me</button>
```
