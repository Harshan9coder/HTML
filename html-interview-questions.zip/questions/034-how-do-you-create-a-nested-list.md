# 34. How do you create a nested list?

```html
A nested list is a list that is contained within another list item. Any type of list can be nested inside another. To create one, you simply place a new <ul> or <ol> element inside an <li> element.12 This is a common way to create outlines or multi-level navigation menus.
```

```html
<ul>    <li>Fruit        <ul>            <li>Apple</li>            <li>Banana</li>        </ul>    </li>    <li>Vegetables        <ol>            <li>Carrot</li>            <li>Broccoli</li>        </ol>    </li></ul>
```
