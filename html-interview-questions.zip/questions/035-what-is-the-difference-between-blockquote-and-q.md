# 35. What is the difference between <blockquote> and <q>?

Both elements are used for quotations, but they differ in their scope and presentation.4

<blockquote>:

This is a block-level element.

It is used for long, multi-line quotations that are set off from the main text.

Browsers typically render this element with indented margins on the left and right.

```html
It can contain other block-level elements, like <p> tags.
```

<q> (Quote):

This is an inline element.

It is used for short, in-sentence quotations.

```html
Browsers automatically add quotation marks around the content of the <q> element, so you do not need to type them manually.
```

Both elements can take a cite attribute, whose value should be a URL pointing to the source of the quotation.

```html
<p>As the W3C states:</p><blockquote cite="https://www.w3.org/TR/html5/grouping-content.html#the-blockquote-element">    <p>The blockquote element represents content that is quoted from another source.</p></blockquote><p>He said, <q>Semantic HTML is essential</q>, and I agree.</p>
```
