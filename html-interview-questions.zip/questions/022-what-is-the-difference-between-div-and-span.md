# 22. What is the difference between <div> and <span>?

```html
<div> and <span> are two of the most commonly used HTML elements, but they serve as generic containers with one fundamental difference: their default display behavior.7
```

```html
<div> (Division):
```

This is a block-level element.

By default, it starts on a new line and takes up the full width available to it, pushing subsequent content to the next line.

It is used to group larger chunks of content or other block-level elements together, often to create major layout sections of a page (e.g., a container, a row, a card).

<span>:

This is an inline element.

By default, it does not start on a new line and only takes up as much width as its content requires.

It is used to group a small, inline portion of content, such as a few words within a paragraph, typically to apply specific styling (like a different color) or to hook into with JavaScript, without disrupting the flow of the text.

```html
<div>This is a div.</div><div>This is another div.</div><p>This is a paragraph with a <span style="color: red;">red span</span> inside it.</p>
```
