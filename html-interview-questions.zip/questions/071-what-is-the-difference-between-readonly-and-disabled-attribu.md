# 71. What is the difference between readonly and disabled attributes?

While both attributes prevent a user from modifying an input field, they have key differences in behavior.2

disabled:

The input is completely unusable and un-clickable.

The input's value is not submitted with the form.

The input cannot receive focus.

It is typically used for fields that are conditionally unavailable.

readonly:

The input cannot be modified by the user, but they can still focus on it and select/copy its text.

The input's value is submitted with the form.

It is typically used when you want to display a value that the user should see but not be able to change, like a pre-filled username or a calculated total.
