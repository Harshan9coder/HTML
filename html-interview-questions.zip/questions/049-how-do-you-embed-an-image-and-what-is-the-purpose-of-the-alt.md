# 49. How do you embed an image, and what is the purpose of the alt attribute?

```html
Images are embedded using the <img> tag, which is a void element.1 It requires two essential attributes:
```

src (Source): Specifies the path or URL to the image file.

alt (Alternative Text): Provides a textual description of the image.

The alt attribute is not optional; it is a cornerstone of web accessibility.7 Its purposes are:

Screen Readers: Assistive technologies read the alt text aloud to users with visual impairments, allowing them to understand the image's content and purpose.

Broken Images: If the image fails to load for any reason (e.g., a wrong path or network issue), the browser will display the alt text in its place.

SEO: Search engines cannot "see" images, so they rely on alt text to understand the image's content, which helps in indexing the image for image search results.

An alt attribute should be descriptive but concise. If an image is purely decorative and provides no informational content, the alt attribute should still be present but left empty (alt="") so that screen readers know to skip it.

```html
<img src="golden-retriever.jpg" alt="A golden retriever puppy playing in a field of grass."><img src="decorative-border.png" alt="">
```
