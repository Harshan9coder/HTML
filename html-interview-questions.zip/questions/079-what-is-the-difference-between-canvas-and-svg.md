# 79. What is the difference between Canvas and SVG?

Canvas and SVG are the two primary technologies for creating graphics on the web, but they operate on fundamentally different principles.3

<canvas>:

Pixel-based (Bitmap): Provides a drawing surface where you can draw graphics pixel by pixel using JavaScript.

Immediate Mode: Once a shape is drawn on the canvas, the browser forgets about it. If you want to move it, you must clear the canvas and redraw the entire scene.

Performance: Generally has better performance for rendering a large number of objects or complex, fast-moving animations.

Use Cases: Ideal for dynamic graphics like games, data visualizations, and image manipulation. It is not accessible as the content is not part of the DOM.

```html
<svg> (Scalable Vector Graphics):
```

Vector-based (XML): Defines graphics as a set of shapes, paths, and text in an XML format.

Retained Mode: Each shape drawn in an SVG is an object in the DOM. You can attach event listeners to individual shapes and manipulate them with CSS and JavaScript.

Scalability: Being vector-based, SVGs scale to any size without losing quality.

Use Cases: Ideal for static or interactive graphics that need to be scalable and accessible, such as logos, icons, and charts.
