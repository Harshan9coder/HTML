# 69. What is the purpose of the <datalist> element?

```html
The <datalist> element provides an "autocomplete" feature for <input> elements.3 It contains a set of
```

```html
<option> elements that represent pre-defined suggestions for the user.
```

```html
To associate a <datalist> with an <input>, the id of the <datalist> must match the list attribute of the <input>. The user will see a dropdown list of the suggestions as they type, but they are still free to enter a value that is not on the list.
```

```html
<label for="browser-choice">Choose your browser from the list:</label><input list="browsers" id="browser-choice" name="browser"><datalist id="browsers">    <option value="Chrome">    <option value="Firefox">    <option value="Safari">    <option value="Edge">    <option value="Opera"></datalist>
```
