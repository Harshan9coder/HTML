# 84. What is the purpose of the time element and its datetime attribute?

```html
The <time> element is a semantic tag used to represent a specific period in time.3 This can be a date, a time, or a duration.
```

```html
While the content between the <time> tags is human-readable, the element's primary power comes from the datetime attribute. This attribute provides the same information in a machine-readable format, which is useful for search engines, calendars, and other automated services to parse and use the data.
```

The datetime attribute must be in a valid format, such as YYYY-MM-DD for a date or YYYY-MM-DDThh:mm:ss for a date and time.4

```html
<p>The conference will be held on <time datetime="2025-10-26">October 26th, 2025</time>.</p><p>The event starts at <time datetime="2025-10-26T19:00-05:00">7:00 PM Central Time</time>.</p>
```
