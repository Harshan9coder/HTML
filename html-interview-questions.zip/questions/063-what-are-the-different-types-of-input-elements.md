# 63. What are the different types of <input> elements?

```html
The <input> element is the most versatile form control, and its behavior is determined by its type attribute.15 Common input types include:
```

text: A single-line text field.

password: A text field where the characters are obscured.

checkbox: A checkbox that can be toggled on or off.

radio: A radio button, typically used in a group where only one can be selected at a time.

submit: A button that submits the form.

button: A generic clickable button, usually controlled by JavaScript.

file: A control for uploading files.

hidden: An input field that is not visible to the user but whose value is submitted with the form.

reset: A button that resets all form controls to their initial values.
