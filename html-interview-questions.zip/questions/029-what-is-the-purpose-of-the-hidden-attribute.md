# 29. What is the purpose of the hidden attribute?

The hidden attribute is a boolean attribute that, when present, indicates that an element is not yet, or is no longer, relevant. Browsers will not render elements that have the hidden attribute specified.2

However, the element is still part of the DOM and can be accessed and manipulated by JavaScript. This makes it a useful tool for hiding content that should only be revealed in response to a user action (e.g., showing a dialog box) or for keeping content available to screen readers while being visually hidden (though CSS techniques are often preferred for this). It is semantically more appropriate than using CSS display: none; when the content's relevance is conditional.

```html
<p>You can see this paragraph.</p><p hidden>You cannot see this paragraph until the 'hidden' attribute is removed by JavaScript.</p><script>    // Example: A button could trigger this code to reveal the hidden content    setTimeout(() => {        const hiddenP = document.querySelector('p[hidden]');        if (hiddenP) {            hiddenP.removeAttribute('hidden');        }    }, 3000);</script>
```
