# 85. How do you handle events in HTML?

Events are actions or occurrences that happen in the browser, such as a user clicking a button, a page finishing loading, or an input field being changed. HTML allows you to respond to these events by using event handler attributes that execute a piece of JavaScript code when the event occurs.15

Event handler attributes are named with an "on" prefix, such as onclick, onmouseover, onkeydown, and onload.

While this method works, the modern and more flexible approach is to use JavaScript's addEventListener() method to attach event listeners to DOM elements. This separates the HTML structure from the JavaScript behavior, which is a core principle of modern web development.

```html
<button onclick="alert('You clicked the button!')">Click Me</button><button id="myButton">Click Me Too</button><script>    const button = document.getElementById('myButton');    button.addEventListener('click', () => {        alert('You clicked the second button!');    });</script>
```

Section VII: Web Accessibility (A11y)

This section is dedicated to the crucial topic of web accessibility (often abbreviated as A11y), covering the principles and techniques required to build inclusive websites that are usable by people with disabilities. A developer who understands accessibility demonstrates a commitment to professional, ethical, and user-centric development.
