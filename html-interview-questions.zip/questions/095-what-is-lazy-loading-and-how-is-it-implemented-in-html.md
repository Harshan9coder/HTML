# 95. What is lazy loading and how is it implemented in HTML?

Lazy loading is a performance optimization technique where the loading of non-critical resources (typically images or iframes) is deferred until they are needed.7 Instead of loading all images on a page at once, lazy loading waits to load an image until the user scrolls and it is about to enter the viewport. This significantly improves initial page load time, saves bandwidth, and reduces memory usage.

```html
The simplest way to implement lazy loading in modern browsers is to use the loading="lazy" attribute directly on <img> and <iframe> tags. This is a native browser feature that requires no JavaScript.
```

For older browsers that do not support this attribute, lazy loading can be implemented using JavaScript with the Intersection Observer API, which provides an efficient way to detect when an element enters the viewport.

```html
<img src="heavy-image.jpg" loading="lazy" alt="An image that will be loaded on demand."><iframe src="https://example.com" loading="lazy" title="An embedded page."></iframe>
```
