# 38. How can you improve the accessibility of HTML tables?

Making tables accessible is crucial for screen reader users to understand the relationships between data cells and their headers. The correct use of table elements is not about visual layout but about defining these data relationships.

```html
Use <caption>: Always provide a <caption> for your table to describe its purpose.
```

```html
Use <th> for Headers: Use <th> elements for all row and column headers, not <td> styled to look like a header.
```

```html
Use the scope Attribute: This is the most important step for complex tables. The scope attribute on a <th> element explicitly tells assistive technologies what the header is for.2
```

scope="col": The header applies to all cells in that column.

scope="row": The header applies to all cells in that row.

```html
A screen reader uses this structure to provide context. When it encounters a <td>, it can announce the corresponding <th> from that row and column, telling the user, for example, "Row: 'Chicago', Column: 'Population', Value: '2.7 million'". Without this structure, the user just hears a jumble of disconnected data points.
```

```html
<table border="1">    <caption>City Information</caption>    <thead>        <tr>            <th scope="col">City</th>            <th scope="col">State</th>            <th scope="col">Population</th>        </tr>    </thead>    <tbody>        <tr>            <th scope="row">Chicago</th>            <td>Illinois</td>            <td>2.7 Million</td>        </tr>        <tr>            <th scope="row">Los Angeles</th>            <td>California</td>            <td>3.9 Million</td>        </tr>    </tbody></table>
```
