# 54. What is SVG and how do you use it in HTML?

SVG stands for Scalable Vector Graphics.5 Unlike raster image formats like JPEG or PNG which are based on pixels, SVG is an XML-based vector image format. This means it describes images using mathematical shapes, paths, and text.

The primary advantages of SVG are 10:

Scalability: SVGs can be scaled to any size without losing quality, making them perfect for responsive design and high-resolution (Retina) displays.

Small File Size: For simple graphics like logos and icons, SVG files are often smaller than their raster counterparts.

Manipulability: Since SVG is XML, it can be styled with CSS and manipulated with JavaScript. Every element within an SVG is part of the DOM.

Accessibility: Text within an SVG remains as text, which is accessible to screen readers and search engines.

There are two main ways to use SVG in HTML:

```html
As an Image: Link to an .svg file using an <img> tag, just like any other image format. This is the simplest method.
```

Inline SVG: Paste the SVG code directly into the HTML document. This allows you to style the individual parts of the SVG with CSS and interact with them using JavaScript.

```html
<img src="logo.svg" alt="Company Logo"><svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">    <circle cx="50" cy="50" r="45" stroke="blue" stroke-width="5" fill="none" /></svg>
```
