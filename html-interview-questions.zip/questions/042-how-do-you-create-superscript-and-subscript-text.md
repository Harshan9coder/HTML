# 42. How do you create superscript and subscript text?

```html
Superscript and subscript text can be created using the <sup> and <sub> tags, respectively.15
```

```html
<sup> (Superscript): Renders text smaller and raised above the baseline. It is used for things like exponents in mathematical formulas (e.g., E=mc2) or ordinal indicators (e.g., 1st).
```

```html
<sub> (Subscript): Renders text smaller and lowered below the baseline. It is used for things like footnotes or chemical formulas (e.g., H2O).
```

```html
<p>The famous equation is E = mc<sup>2</sup>.</p><p>The chemical formula for water is H<sub>2</sub>O.</p>
```
