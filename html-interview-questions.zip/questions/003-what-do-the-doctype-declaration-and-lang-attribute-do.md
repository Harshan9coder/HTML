# 3. What do the <!DOCTYPE> declaration and lang attribute do?

The <!DOCTYPE> declaration is a critical instruction for the web browser, not an HTML tag itself.4 Its primary function is to inform the browser about the version of HTML the document is written in.1 For modern web pages, the declaration is simple:

<!DOCTYPE html>.2

This declaration is the foundational switch that dictates the browser's entire rendering behavior. Its presence ensures the browser uses "standards mode," which interprets the HTML and CSS according to the latest W3C specifications, leading to consistent and predictable rendering across different browsers.11 If the

<!DOCTYPE> is omitted or incorrect, the browser falls back into "quirks mode," a backward-compatibility mode that emulates the non-standard behaviors of older browsers like Internet Explorer 5.11 This can cause significant layout inconsistencies and bugs. Therefore, this single line of code can be seen as the developer's contract with the browser, promising to adhere to standards in exchange for predictable rendering.

```html
The lang attribute, typically placed on the <html> tag (e.g., <html lang="en">), specifies the primary language of the document's content.1 This is crucial for:
```

Accessibility: It allows screen readers to switch to the correct language profile to pronounce the text accurately.

Search Engines: It helps search engines understand the language of the content, which can improve search results for users filtering by language.

Browsers: It can influence browser functions like translation prompts or spell-checking.

```html
<!DOCTYPE html><html lang="en-US"><head>    <title>A Properly Declared Page</title></head><body>    <p>This content is in American English.</p></body></html>
```
