# 18. Explain the purpose of key HTML5 semantic elements like <header>, <footer>, <nav>, <main>, <article>, <section>, and <aside>.

HTML5 introduced a suite of new elements designed to give developers a standardized vocabulary for describing the main sections of a webpage.3

```html
<header>: Represents introductory content for its nearest ancestor sectioning content or for the page as a whole. This typically includes a logo, the site name, a search form, or the main navigation.8
```

```html
<footer>: Represents the footer for its nearest ancestor sectioning content or for the page as a whole. This usually contains information like copyright notices, contact information, and links to related documents.8
```

```html
<nav>: Represents a section of the page whose purpose is to provide navigation links, either within the current document or to other documents. It is intended for major navigation blocks.8
```

```html
<main>: Represents the dominant, main content of the <body> of a document. There should only be one <main> element per page, and it should not be a descendant of an <article>, <aside>, <footer>, <header>, or <nav> element.8
```

```html
<article>: Represents a self-contained, complete composition in a document that is intended to be independently distributable or reusable (e.g., in syndication). Examples include a forum post, a magazine or newspaper article, or a blog entry.6
```

```html
<section>: Represents a generic standalone section of a document, which doesn't have a more specific semantic element to represent it. It typically has a heading and groups a thematic set of content.6
```

```html
<aside>: Represents a portion of a document whose content is only tangentially related to the document's main content. Asides are often represented as sidebars or call-out boxes.8
```

```html
<body>    <header>        <h1>My Blog</h1>        <nav>            <ul>                <li><a href="/">Home</a></li>                <li><a href="/archive">Archive</a></li>            </ul>        </nav>    </header>    <main>        <article>            <h2>The Importance of Semantic HTML</h2>            <section>                <h3>For Accessibility</h3>                <p>Details about accessibility...</p>            </section>            <section>                <h3>For SEO</h3>                <p>Details about SEO...</p>            </section>        </article>        <aside>            <h3>About the Author</h3>            <p>Bio goes here...</p>        </aside>    </main>    <footer>        <p>© 2025 My Blog</p>    </footer></body>
```
