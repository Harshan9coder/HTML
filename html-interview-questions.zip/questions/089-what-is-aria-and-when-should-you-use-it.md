# 89. What is ARIA and when should you use it?

ARIA stands for Accessible Rich Internet Applications. It is a set of special accessibility attributes that can be added to any HTML markup to help make web content and web applications more accessible to people with disabilities.7

ARIA is particularly useful for making dynamic content and advanced user interface controls (widgets) accessible, especially those developed with JavaScript for which there is no native HTML equivalent (e.g., a custom slider, a tabbed interface, or an autocomplete dropdown).

ARIA provides three main features:

Roles: Define what an element is or does (e.g., role="navigation", role="button", role="alert").

Properties: Define characteristics of elements (e.g., aria-required, aria-labelledby).

States: Define the current conditions of elements (e.g., aria-disabled, aria-expanded).
