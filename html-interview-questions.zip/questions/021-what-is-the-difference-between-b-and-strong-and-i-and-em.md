# 21. What is the difference between <b> and <strong>, and <i> and <em>?

This question tests the understanding of semantic meaning versus presentational styling.1 Visually, a browser renders

```html
<b> and <strong> text as bold, and <i> and <em> text as italicized. However, their semantic meanings are entirely different.
```

```html
<b> (Bold) vs. <strong> (Strong Importance):
```

```html
The <b> tag is a presentational element. It simply applies a bold font weight to the text for visual emphasis without implying any extra importance.1 It should be used when you want to draw attention to text stylistically, such as for a product name in a review.
```

```html
The <strong> tag is a semantic element. It indicates that the enclosed text has strong importance, seriousness, or urgency.1 Screen readers may change their voice inflection to convey this importance, and search engines may give the text slightly more weight.
```

```html
<i> (Italic) vs. <em> (Emphasis):
```

```html
The <i> tag is presentational. It renders text in an italic style and is typically used for things like a thought, a technical term, a foreign phrase, or a ship's name, where the text is offset from the normal prose but doesn't carry added emphasis.4
```

```html
The <em> tag is semantic. It indicates stress emphasis on the enclosed text.4 Like<strong>, screen readers may alter their pronunciation to reflect this emphasis.
```

```html
Rule of thumb: If the meaning of the sentence changes when the tag is removed, use <strong> or <em>. If only the styling is lost, <b> or <i> may be appropriate.
```

```html
<p>This is a <b>bold</b> word for visual effect.</p><p><strong>Warning:</strong> Do not touch the live wire.</p><p>The term <i>Homo sapiens</i> is Latin.</p><p>You <em>must</em> complete this task today.</p>
```
