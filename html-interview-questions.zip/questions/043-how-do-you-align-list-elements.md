# 43. How do you align list elements?

Historically, list alignment might have been attempted with HTML attributes, but the modern and correct way to align list elements is with CSS.5 The

```html
text-align property can be applied to the <ul> or <ol> element to align the text within each list item. For more complex alignment, such as aligning the bullet points or numbers themselves, properties like list-style-position or Flexbox/Grid on the list container can be used. Indentation of nested lists is handled automatically by the browser's default styles but can be customized with CSS padding or margin on the nested list element.
```

```html
<style>   .centered-list {        text-align: center;        list-style-position: inside; /* Aligns markers inside the text block */    }</style><ul class="centered-list">    <li>Item one</li>    <li>Item two</li>    <li>Item three</li></ul>
```
