# 82. What is the Application Cache and Manifest file?

The Application Cache (AppCache) was an HTML5 feature designed to allow web applications to be used offline.3 It worked by specifying a

```html
manifest file (a text file with a .appcache extension) in the <html> tag's manifest attribute. This file listed the resources (HTML, CSS, JS, images) that the browser should cache locally.
```

However, the Application Cache was found to have significant design flaws and was difficult to work with. It has since been deprecated and removed from web standards. The modern and recommended technology for creating offline-capable web applications is Service Workers, which are part of the Progressive Web App (PWA) technology suite and offer much more power and flexibility.
