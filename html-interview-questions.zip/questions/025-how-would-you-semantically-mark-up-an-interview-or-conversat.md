# 25. How would you semantically mark up an interview or conversation?

```html
This question tests the ability to apply semantic principles to a less common content structure. There is no single <interview> tag, so one must compose a solution from existing semantic elements. A good approach would be to use a description list (<dl>) or a series of paragraphs with strong or cite tags.22
```

```html
Using a <dl> is often a strong choice because a conversation is fundamentally a series of terms (the speaker) and descriptions (what they said).
```

```html
<dl>    <dt>Interviewer</dt>    <dd>What is your greatest strength?</dd>    <dt>Candidate</dt>    <dd>My ability to apply semantic HTML principles to solve complex structural problems.</dd></dl>
```

```html
Another valid approach could involve using <p> tags and using <strong> or <b> to identify the speaker.
```

```html
<p><strong>Interviewer:</strong> What is your greatest strength?</p><p><strong>Candidate:</strong> My ability to apply semantic HTML principles to solve complex structural problems.</p>
```
